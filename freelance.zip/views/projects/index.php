<?php

use yii\helpers\Html;
use yii\grid\GridView;

/* @var $this yii\web\View */
/* @var $searchModel app\models\ProjectsSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = 'Projects';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="projects-index">

    <h1>
        <?= Html::encode($this->title) ?>
        <p class="pull-right">
            <?= Html::a('Create Projects', ['create'], ['class' => 'btn btn-success']) ?>
        </p>
    </h1>
    
    <?php // echo $this->render('_search', ['model' => $searchModel]); ?>

    
    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'filterModel' => $searchModel,
        'columns' => [
            //['class' => 'yii\grid\SerialColumn'],

            'project_id',
            'name',
            array(
                'header'  => 'Total',
                'format' => 'html',
                'value' => 'total'
            ),
            //'type',
            //'rate',
            //'amount',
            'paid',
            //'status',
            'date_added',

            ['class' => 'yii\grid\ActionColumn'],
        ],
    ]); ?>

</div>

<?php $this->registerJs("
$(document).ready(function(){
    $('input[name=\'ProjectsSearch[project_id]\']').parent().css('width', '70px');
});");
?>