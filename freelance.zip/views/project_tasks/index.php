<?php

use yii\helpers\Html;
use yii\grid\GridView;

/* @var $this yii\web\View */
/* @var $searchModel app\models\ProjectTasksSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = 'Project Tasks';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="project-tasks-index">

    <h1>
        <?= Html::encode($this->title) ?>
        <p class="pull-right">
            <?= Html::a('Create Project Tasks', ['create'], ['class' => 'btn btn-success']) ?>
        </p>
    </h1>
    
    <?php // echo $this->render('_search', ['model' => $searchModel]); ?>

    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'filterModel' => $searchModel,
        'columns' => [
            ['class' => 'yii\grid\SerialColumn'],

            'project_task_id',
            'project_id',
            'name',
            'start_time',
            'end_time',
            // 'note:ntext',

            ['class' => 'yii\grid\ActionColumn'],
        ],
    ]); ?>

</div>

<?php $this->registerJs("
$(document).ready(function(){
    $('input[name=\'ProjectTasksSearch[project_id]\']').parent().css('width', '70px');
    $('input[name=\'ProjectTasksSearch[project_task_id]\']').parent().css('width', '70px');
});");
?>