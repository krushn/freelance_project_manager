<?php

return [
    'class' => 'yii\db\Connection',
    'dsn' => 'mysql:host=localhost;dbname=freelance',
    'username' => 'root',
    'password' => '',
    'charset' => 'utf8',
];
